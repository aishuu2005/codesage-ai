from services.pylint_service import run_pylint
from services.bandit_service import run_bandit
from services.radon_service import run_radon


def analyze_file(file_path):
    """
    Runs all static analysis tools on the uploaded file.
    """

    pylint_output = run_pylint(file_path)
    bandit_output = run_bandit(file_path)
    radon_output = run_radon(file_path)

    # ---------- Calculate Security Issues ----------
    if "No issues identified" in bandit_output:
        security_issues = 0
    else:
        security_issues = bandit_output.count(">> Issue:")

    # ---------- Calculate Quality Score ----------
    quality_score = "Unknown"

    if "rated at" in pylint_output:
        try:
            rating = pylint_output.split("rated at")[1].split("/10")[0].strip()
            quality_score = f"{rating}/10"
        except Exception:
            quality_score = "Unknown"

    # ---------- Calculate Complexity ----------
    if radon_output.startswith("ERROR"):
        complexity = "Error"
    elif "No functions or classes" in radon_output:
        complexity = "No functions found"
    elif " A " in radon_output or " - A " in radon_output:
        complexity = "A (Low Complexity)"
    elif " B " in radon_output or " - B " in radon_output:
        complexity = "B (Moderate Complexity)"
    elif " C " in radon_output or " - C " in radon_output:
        complexity = "C (Complex)"
    elif " D " in radon_output or " - D " in radon_output:
        complexity = "D (High Complexity)"
    else:
        complexity = "Unknown"

    return {
        "summary": {
            "quality_score": quality_score,
            "security_issues": security_issues,
            "complexity": complexity
        },
        "pylint": pylint_output,
        "bandit": bandit_output,
        "radon": radon_output
    }