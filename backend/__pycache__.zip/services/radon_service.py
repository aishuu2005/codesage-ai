import subprocess
import sys


def run_radon(file_path):
    """
    Runs Radon complexity analysis on a Python file.
    """

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "radon",
            "cc",
            file_path,
            "-s"
        ],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        return f"ERROR:\n{result.stderr}"

    output = result.stdout.strip()

    if not output:
        return "No functions or classes found to analyze."

    return output